<?php

$key1 = 'YLsDS4paBS0H8hKNCK1BUQOZGyx8WAk';

?>

