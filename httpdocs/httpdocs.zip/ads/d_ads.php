<?php
$ads1 = '<img src="http://i49.photobucket.com/albums/f252/NightWing726/500x100.png">';
$ads2 = '<img src="http://www.bannerinspiration.com/assets/uploads/r_27_f.jpg">';
$ads3 = '<img src="http://www.zaptones.com/assets/ad300600.jpg">';
//$ads1 = file_get_contents("http://funnymiku.in/ads/468x60.txt");
//$ads2 = file_get_contents("http://funnymiku.in/ads/320x250.txt");
//$ads3 = file_get_contents("http://funnymiku.in/ads/300x600.txt");

?>
