<?php
$file = "style_m.css";
$ads1 = file_get_contents("http://funnymiku.in/ads/320x100.txt");
$ads2 = file_get_contents("http://funnymiku.in/ads/320x250.txt");
$ads3 = "";
?>
