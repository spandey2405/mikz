<?php
$servername = "182.50.133.79:3306";
$username = "spandey2405";
$password = "Siddyking123@1121";
$dbname = "spandey2405_ms";
?>

