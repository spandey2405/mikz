<?php

$defaultdata["type"]="jokes";
//$url["checkfolder"]="http://funnymiku.in/check-folders.php?p=1&type=";
//$url["makepost"]="http://funnymiku.in/make-post.php?p=1&a=1&post=";
$url["checkfolder"]="http://localhost/httpdocs/check-folders.php?p=1&type=";
$url["makepost"]="http://localhost/httpdocs/make-post.php?p=1&a=1&post=";
?>

