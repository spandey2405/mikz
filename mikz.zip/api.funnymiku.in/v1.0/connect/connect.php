<?php

// main godaddy server settings 

//$servername = "182.50.133.79:3306";
//$username = "spandey2405";
//$password = "Siddyking123@1121";
//$dbname = "spandey2405_ms";

// local host settings

$servername = "localhost";
$username = "root";
$password = "Siddyking";
$dbname = "spandey2405_ms";

?>
