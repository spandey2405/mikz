<?php print_r($_SERVER); ?>
